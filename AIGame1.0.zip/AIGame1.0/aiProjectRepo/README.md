# Artificial-Intelligence-Mancala
This is an Adversarial Search (Game)
How to Build:

Windows:
1. Download QTcreator(opensource 5.4) http://www.qt.io/download-open-source/
2. Once you have QT creator, click on Game (QT project file)
3. This will open the QT framework
4. Build

Linux:
1. $qmake Game.pro
2. $make

How to Run:

Windows:
1. Successful build
2. Run (green play button)
3. Select from menu (single player, dual player, or dual agents)
	1. play the game :)
	
Linus:
1. ./Game
2. Select from menu (single player, dual player, or dual agents)
	1. play the game :)
	
This Game allows you to simulate two Agents playing mancala. It also allows two people to play mancala, and allows one player to play an agent. 