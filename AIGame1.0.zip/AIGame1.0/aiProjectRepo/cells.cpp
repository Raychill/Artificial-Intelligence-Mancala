#include "cells.h"

cells::cells()
{
    cellNum = 0;
    marbelNum = 0;
    button = NULL;
    isBank = false;

} // End of cells().

cells::~cells()
{
    // Do nothing.
}
